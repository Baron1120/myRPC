package com.baron.test;

import com.baron.rpc.annotation.RpcScan;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@RpcScan(basePackage = {"com.baron"})
public class TestClient {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(TestClient.class);
        String[] names = applicationContext.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name);
        }
        HelloController helloController = (HelloController) applicationContext.getBean("helloController");
        try {
            helloController.test();
        } catch (Exception e) {

        }

    }
}
