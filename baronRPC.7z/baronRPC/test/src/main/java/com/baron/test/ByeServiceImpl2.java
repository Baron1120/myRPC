package com.baron.test;

import com.baron.rpc.annotation.RpcService;
import com.baron.rpc.api.ByeService;


@RpcService(group = "test1", version = "version2")
public class ByeServiceImpl2 implements ByeService {

    @Override
    public String bye(String name) {
        return "基于Spring的bye方法, " + name;
    }
}
