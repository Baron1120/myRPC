package com.baron.test;

import com.baron.rpc.annotation.RpcScan;
import com.baron.rpc.annotation.ServiceScan;
import com.baron.rpc.transport.serializer.CommonSerializer;
import com.baron.rpc.xserver.RpcServer;
import com.baron.rpc.xserver.NettyServer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


@RpcScan(basePackage = {"com.baron"})
public class TestServer {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(TestServer.class);
        String[] names = applicationContext.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name);
        }
        NettyServer nettyRpcServer = (NettyServer) applicationContext.getBean("nettyServer");
        nettyRpcServer.start();
//        RpcServer server = new NettyServer("127.0.0.1", 9999, CommonSerializer.PROTOBUF_SERIALIZER);
//        server.start();

    }

}
