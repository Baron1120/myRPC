package com.baron.rpc.api;


public interface HelloService {

    String hello(HelloObject object);

}
