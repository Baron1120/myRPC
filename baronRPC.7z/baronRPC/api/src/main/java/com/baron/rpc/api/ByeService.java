package com.baron.rpc.api;


public interface ByeService {

    String bye(String name);

}
